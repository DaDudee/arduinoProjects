#!/bin/bash

curl -X POST \
--data-binary @${1} \
--header 'Content-Type: audio/x-flac; rate=16000;' \
--user-agent 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2446.0 Safari/537.36' \
"https://www.google.com/speech-api/full-duplex/v1/up?key=AIzaSyBOti4mM-6x9WDnZIjIeyEU21OpBXqWBgw&pair=A6A08F0FF85A1254&output=json&lang=${2}&pFilter=2&maxAlternatives=1&client=chromium&continuous&interim"
