#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <errno.h>

#define 	STRING_SIZE	512
#define 	BUF_SIZE	1024
#define 	TCPIP_PORT	4966
#define 	LOCALHOST	"localhost"

int main(argc,argv)
int  argc;
char *argv[];
{
  int	n,n_read,n_write,n_written,addr_len,propagate;
  int	sender,port_num,fd_in,fd_out;
  char	*buf;

  static char	buffer[BUF_SIZE],host_name[STRING_SIZE];

  struct 	hostent 	*host_addr;
  struct 	sockaddr_in	sin_addr;


  port_num=TCPIP_PORT;
  sprintf(host_name,LOCALHOST);
  propagate = 0;

  /* 
  ** Check arguments
  */

  if(argc>1)
  {
    for(n=1;n<argc;n++)
    {
      if(!strncmp(argv[n],"-host",5) && n<argc-1)
      {
        if(strlen(argv[n+1])>STRING_SIZE-1)
        {
          fprintf(stderr,"\n%s: Remote hostname is too long! :(\n\n",argv[0]);
          exit(1);
        }
        strcpy(host_name,argv[n+1]);
      }

      if(!strncmp(argv[n],"-port",5) && n<argc-1)
        port_num=atoi(argv[n+1]);

      if(!strncmp(argv[n],"-propagate",10))
        propagate=1;


      if(!strncmp(argv[n],"-help",5))
      {
        fprintf(stderr,"\n                        -= TCP/IP Stream Data Sender =-\n");
        fprintf(stderr,"                 Simon Dobri�ek, Copyright (c) November, 1995\n");
        fprintf(stderr,"                 ------------------------------------------\n\n");
        fprintf(stderr,"              Current parameters: Remote host name=%s\n",host_name);
        fprintf(stderr,"                                       TCP/IP port=%d\n",port_num);
        fprintf(stderr,"                                       Propagation=false\n\n");
        fprintf(stderr,"               Optional Switches: -host <remote hostname>\n");
        fprintf(stderr,"                                  -port <port number>\n");
        fprintf(stderr,"                                  -propagate\n\n");
        exit(0);
      }
    }
  }

  if((host_addr=gethostbyname(host_name))==NULL)
    if((host_addr=gethostbyaddr(host_name,sizeof(argv[1]),AF_INET))==NULL)
    {
      fprintf(stderr,"\n%s: Host %s lookup failure  ... %s  :( \n\n",argv[0],host_name,strerror(errno));
      exit(1);
    }

  memset(&sin_addr,0,sizeof(sin_addr));
  sin_addr.sin_family=AF_INET;
  sin_addr.sin_port=htons(port_num);
  memcpy(&sin_addr.sin_addr,host_addr->h_addr,host_addr->h_length);

  if((sender=socket(AF_INET,SOCK_STREAM,0))<0)
  {
    fprintf(stderr,"\n%s: Socket creation failed ... %s  :(\n\n",argv[0],strerror(errno));
    exit(1);
  }

  addr_len = sizeof(sin_addr);
  if((connect(sender,(struct sockaddr *)&sin_addr,addr_len))<0)
  {
    fprintf(stderr,"\n%s: Connect failed ... %s  :(\n\n",argv[0],strerror(errno));
    exit(1);
  }

  fd_in = fileno(stdin);
  fd_out = fileno(stdout);

  for(;;)
  {
    if((n_read=read(fd_in,buffer,BUF_SIZE))<=0)
    {
      if(n_read < 0)
        fprintf(stderr,"\n%s: Read failed ... %s  :(\n\n",argv[0],strerror(errno));
      exit(1);
    }

    n_write = n_read;

    for(buf=buffer; n_read ; n_read-=n_written, buf+=n_written)
      if((n_written=write(sender,buf,n_read))<=0)
      {
        fprintf(stderr,"\n%s: Write failed ... %s  :(\n\n",argv[0],strerror(errno));
        exit(1);
      }

    n_read = n_write;
    
    if(propagate)
    {
      for(buf=buffer; n_read ; n_read-=n_written, buf+=n_written)
        if((n_written=write(fd_out,buf,n_read))<=0)
        {
          fprintf(stderr,"\n%s: Write failed ... %s  :(\n\n",argv[0],strerror(errno));
          exit(1);
        }
    }
  }
  return 0;
}
