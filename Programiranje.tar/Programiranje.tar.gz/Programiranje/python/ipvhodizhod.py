#!/usr/bin/python

import socket
import sys
import time

if __name__=='__main__':
	inhost = 'localhost'
	inport = 9990
	outhost = 'localhost'
	outport = 9991
         
	try:
		acceptor = None
		commander = None
		synthesizer = None

		try:
			acceptor = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			acceptor.bind((inhost,inport))
			acceptor.listen(1)
			commander, address = acceptor.accept()
			commander.settimeout(0.001)
		except socket.error as error_message:
			print('Ne morem se povezati z dajalnikom ukazov!')
			raise 
			
		try:
			synthesizer = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
			synthesizer.connect((outhost,outport))
		except socket.error as error_message:
			print('Ne morem se povezati s sintetizatorjem!')
			raise 
        
		while True:
			print('Vodim Roombo ...')
			#Izvedi potrebne operacije za vodenje Roombe.			
			time.sleep(0.5)

			command = None			
			try:
				command = commander.recv(128)
			except socket.timeout:
				pass
			except socket.error as error_message:
				print(error_message)
				raise

			if command:
				command = command.strip()
				print('Dobil sem ukaz: %s' % command)

				if command == 'levo':
					message = 'Zavijam levo!'
				elif command == 'desno':
					message = 'Zavijam desno!'
				elif command == 'izklop':
					message = 'Izklapljam se! Adijo!'
				else:
					message = 'Ne razumem! Prosim, ponovi ukaz!'

				print(message)
				
				try:
					synthesizer.sendall(message+'\n')
				except socket.error as error_message:
					print(error_message)
					raise

				if command == 'izklop':
					break            
	finally:
		if acceptor != None:
			acceptor.close()
		if commander != None:
			commander.close()
		if synthesizer != None:
			commander.close()

