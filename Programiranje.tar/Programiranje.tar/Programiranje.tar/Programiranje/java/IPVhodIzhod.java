import java.io.*;
import java.net.*;

class IPVhodIzhod 
{
	public static void main(String[] args) 
	{
		String inhost = "localhost";
		int inport = 9990; 

		String outhost = "localhost";
		int outport = 9991;

		ServerSocket acceptor = null;
		Socket commander_socket = null;
		Socket synthesizer_socket = null;

		try
		{
			acceptor = new ServerSocket(inport);
			commander_socket = acceptor.accept();
			commander_socket.setSoTimeout(1);
			synthesizer_socket = new Socket(outhost, outport);

			DataInputStream commander = new DataInputStream(commander_socket.getInputStream());
			PrintStream synthesizer = new PrintStream(synthesizer_socket.getOutputStream());

			while (true)
			{
				System.out.println("Vodim Roombo ...");
				//Izvedi potrebne operacije za vodenje Roombe.			
 				try
				{
					Thread.sleep(500);
				}
				catch (InterruptedException ie)
				{
				}

				byte[] command_buffer = new byte[128];
				int num_read = 0;

				try
				{
					num_read = commander.read(command_buffer);
				}
				catch (java.net.SocketTimeoutException e)
				{
				}

				if (num_read < 0)
				{
					System.out.println("Prekinjena povezava z dajalnikom ukazov!");
					break;
				}

				if (num_read > 0)
				{
					String command = new String(command_buffer).trim();					

					if (command.isEmpty() == true)
						continue;

					System.out.println("Dobil sem ukaz: \"" + command + "\"");

					String message = "";

					if (command.equals("levo"))
					{
						message = "Zavijam levo!"; 
					}
					else if (command.equals("desno"))
					{
						message = "Zavijam desno!"; 
					}
					else if (command.equals("izklop"))
					{
						message = "Izklapljam se! Adijo!"; 
					}
					else
					{
						message = "Ne razumem! Prosim, ponovi ukaz!"; 
					}

					System.out.println(message);
					synthesizer.println(message);

					if (command.equals("izklop"))
						break;
				}
			}
		}
		catch(IOException e)
		{
			System.out.println(e);
		}
		finally
		{
			try
			{
				if (commander_socket != null)
					commander_socket.close();
				if (acceptor != null)
					acceptor.close();
				if (synthesizer_socket != null)
					synthesizer_socket.close();
			}
			catch(IOException e)
			{
				System.out.println(e);
			}
		} 
	}
}

