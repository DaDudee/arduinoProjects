#!/usr/bin/python

import sys, time
import summer_sockets as soc
import socket

if __name__=='__main__':
    inhost = 'localhost'
    inport = 9990
    outhost = 'localhost'
    outport = 9991
    if len(sys.argv)>1:
        inhost = sys.argv[1]
    if len(sys.argv)>2:
        inport = int(sys.argv[2])
    if len(sys.argv)>3:
        outhost = sys.argv[3]
    if len(sys.argv)>4:
        outport = int(sys.argv[4])
        
    print 'Usage: %s inhost=%s inport=%s outhost=%s outport=%s' % (sys.argv[0], inhost, inport, outhost, outport)
    
    server = soc.ThreadedTcpServer((inhost, inport), soc.TcpRequestHandler)
    try:
        soc.startThreadedServer(server)
        
        while True:
            cmd = server.getData()
            if cmd:
                print 'Command: %s' % cmd
                
                if cmd=='levo':
                    message = 'Rumba, zavij levo!'
                elif cmd=='desno':
                    message = 'Rumba, zavij desno!'
                else:
                    message = 'Ne razumem. Prosim, ponovi ukaz.'
                
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                try:
                    sock.connect((outhost, outport))
                    sock.sendall(message +'\n')
                except:
                    pass
                finally:
                    sock.close()
            
            time.sleep(0.03)
    finally:
        server.shutdown()
