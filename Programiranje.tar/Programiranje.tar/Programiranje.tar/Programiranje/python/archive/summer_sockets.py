#!/usr/bin/python

# https://docs.python.org/2/library/socketserver.html
# https://docs.python.org/2/library/threading.html

import SocketServer
import socket, fcntl, errno
import threading

import sys
import time

#
# Request handlers, data container and threaded servers
#
        
class BufTcpRequestHandler(SocketServer.StreamRequestHandler):
    '''Buffered TCP request handler
    
    Received data is appended to the previously received data.'''

    def handle(self):
        # Store data
        self.server._lock.acquire()
        self.server._data.append(self.rfile.readline())
        self.server._lock.release()
        
#        # Send response
#        self.wfile.write("ACK")

class TcpRequestHandler(SocketServer.StreamRequestHandler):
    '''TCP request handler
    
    Previously received data is replaced for the latest data.'''

    def handle(self):
        # Store data
        self.server._lock.acquire()
        self.server._data = [self.rfile.readline()]
        self.server._lock.release()
            
#        # Send response
#        self.wfile.write("ACK")

class BufUdpRequestHandler(SocketServer.BaseRequestHandler):
    '''Buffered UDP request handler
    
    Received data is appended to the previously received data.'''

    def handle(self):
        # Store data
        self.server._lock.acquire()
        self.server._data.append(self.request[0])
        self.server._lock.release()
        
#        # Send response
#        socket = self.request[1]
#        socket.sendto("ACK", self.client_address)

class UdpRequestHandler(SocketServer.BaseRequestHandler):
    '''UDP request handler
    
    Previously received data is replaced for the latest data.'''

    def handle(self):
        # Store data
        print 'UDP'
        self.server._lock.acquire()
        self.server._data = [self.request[0]]
        self.server._lock.release()
        
#        # Send response
#        socket = self.request[1]
#        socket.sendto("ACK", self.client_address)

class DataContainer():
    '''Data container
    
    Container to hold the received data.'''
    
    def __init__(self):
        self._lock = threading.Lock()
        self._data = []
        
    def getData(self):
        '''Pop-off the data from the queue according to FIFO approach.'''
        
        self._lock.acquire()
        if len(self._data):
            data = self._data.pop(0).strip()
        else:
            data = ''
        self._lock.release()
        return data

class ThreadedTcpServer(SocketServer.ThreadingMixIn, SocketServer.TCPServer, DataContainer):
    '''Threaded TCP server'''

    def __init__(self, serverAddress, requestHandlerClass, bindAndActivate=True):
        SocketServer.TCPServer.__init__(self, serverAddress, requestHandlerClass, bindAndActivate)
        DataContainer.__init__(self)
        
class ThreadedUdpServer(SocketServer.ThreadingMixIn, SocketServer.UDPServer, DataContainer):
    '''Threaded UDP server'''

    def __init__(self, serverAddress, requestHandlerClass, bindAndActivate=True):
        SocketServer.UDPServer.__init__(self, serverAddress, requestHandlerClass, bindAndActivate)
        DataContainer.__init__(self)

def startThreadedServer(server):
    the = threading.Thread(target=server.serve_forever)
    # Exit the server thread when the main thread terminates
    the.daemon = True
    the.start()
    return the



if __name__=='__main__':
    mode = ''
    host = 'localhost'
    port = 9999
    t = 0.03
    if len(sys.argv)>1:
        mode = sys.argv[1]
    if len(sys.argv)>2:
        host = sys.argv[2]
    if len(sys.argv)>3:
        port = int(sys.argv[3])
    if len(sys.argv)>4:
        t = float(sys.argv[4])
        
    print 'Host: %s, port: %d' % (host, port)

    if mode=='tcpserver' or mode=='buftcpserver' or mode=='udpserver' or mode=='bufudpserver':
        if mode=='tcpserver':
            print 'TCP server'
            server = ThreadedTcpServer((host, port), TcpRequestHandler)
        elif mode=='buftcpserver':
            print 'Buffered TCP server'
            server = ThreadedTcpServer((host, port), BufTcpRequestHandler)
        elif mode=='udpserver':
            print 'UDP server'
            server = ThreadedUdpServer((host, port), UdpRequestHandler)
        elif mode=='bufudpserver':
            print 'Buffered UDP server'
            server = ThreadedUdpServer((host, port), BufUdpRequestHandler)
        
        try:
            startThreadedServer(server)
            
            while True:
                data = server.getData()
                if data:
                    print 'Data: %s' % data
                
                time.sleep(t)
        finally:
            server.shutdown()
            
            
            
    elif mode=='tcpclient':
        print 'TCP client'
        
        while True:
            data = raw_input()
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            try:
                sock.connect((host, port))
                sock.sendall(data +'\n')
            except:
                raise
            finally:
                sock.close()



    elif mode=='udpclient':
        print 'UDP client'
        
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            while True:
                data = raw_input()
                sock.sendto(data +'\n', (host, port))
        finally:
            sock.close()
            
            
            
    else:
        print 'Usage: %s tcpserver|udpserver|buftcpserver|bufudpserver|tcpclient|udpclient [host [port [t]]]' % sys.argv[0]
