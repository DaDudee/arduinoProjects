#include <string.h>
#include <unistd.h>

#include <string>
#include <iostream>
#include <sstream>

#include <tcpacceptor.h>
#include <tcpconnector.h>

using namespace std;

int main(int argc, char** argv) 
{
	const char* inhost = "localhost";
	int inport = 9990; 

	const char* outhost = "localhost";
	int outport = 9991; 

	try
	{
		TCPAcceptor* acceptor = new TCPAcceptor(inport,inhost);
		
		if (acceptor->start() != 0)
		{
			cerr << "Ne morem pognati sprejemnika ukazov!" << endl;
			return 1;
		}

		TCPStream* commander = acceptor->accept();

		if (commander == NULL)
		{
			cerr << "Ne morem se povezati z dajalnikom ukazov!" << endl;
			return 1;
		}

		TCPConnector* connector = new TCPConnector();
		TCPStream* synthesizer = connector->connect(outhost, outport);

		if (synthesizer == NULL)
		{
			cerr << "Ne morem se priključiti na sintetizator!" << endl;
			return 1;
		}


		string command;
		char command_buffer[128];
		ssize_t command_size;

		stringstream message;

		while (true)
		{
			cout << "Vodim Roombo ..." << endl;
			//Izvedi potrebne operacije za vodenje Roombe.			
			usleep(500000);

			memset(command_buffer, 0, sizeof(command_buffer));		
			command_size = commander->receive(command_buffer, sizeof(command_buffer),1);

			if (command_size == TCPStream::connectionClosed)
			{
				cerr << "Prekinjena povezava z dajalnikom ukazov!" << endl;
				return 1;
			}

			if (command_size == TCPStream::connectionReset)
				cerr << "Resetirana povezava z dajalnikom ukazov!" << endl;

			if (command_size > 0)
			{
				command_buffer[command_size] = 0;		
				command = command_buffer;

				command.erase(0, command.find_first_not_of(" \n\t\r"));
				command.erase(command.find_last_not_of(" \n\t\r")+1);
				
				if (command.empty() == true)
					continue;

				cout << "Dobil sem ukaz: \"" << command << "\"" << endl;
		
				message.str("");

				if (command == "levo")
				{
					message << "Zavijam levo!" << endl; 
				}
				else if (command == "desno")
				{
					message << "Zavijam desno!" << endl; 
				}
				else if (command == "izklop")
				{
					message << "Izklapljam se! Adijo!" << endl; 
				}
				else
				{
					message << "Ne razumem! Prosim, ponovi ukaz!" << endl; 
				}

				cout << message.str();
				
				if ( synthesizer->send(message.str().c_str(),message.str().size()) != (ssize_t)message.str().size())
					cerr << "Sporočilo ni bilo uspešno poslano sintetizatorju!" << endl;

				if (command == "izklop")
					break;
			}
		}
	}
	catch(exception& e)
	{
 		cerr << e.what() << endl;
	}

	return 0;
}

