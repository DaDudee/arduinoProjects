#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>

#include <string>
#include <iostream>
#include <sstream>

using namespace std;


bool is_unput_available(void)
{
    int fd = fileno(stdin);

    fd_set sdset;
    struct timeval tv;

    tv.tv_sec = 0;
    tv.tv_usec = 0;

    FD_ZERO(&sdset);
    FD_SET(fd, &sdset);

    if (select(fd+1, &sdset, NULL, NULL, &tv) > 0)
        return true;

    return false;
}


int main(void) 
{
	string command;
	char command_buffer[128];

	stringstream message;

	while (true)
	{
		cout << "Vodim Roombo ..." << endl;
		//Izvedi potrebne operacije za vodenje Roombe.			
		usleep(500000);

		if (is_unput_available() == false )
			continue;
		
		memset(command_buffer, 0, sizeof(command_buffer));		
		cin.getline(command_buffer, sizeof(command_buffer));
		
		command = command_buffer;		
		command.erase(0, command.find_first_not_of(" \n\t\r"));
		command.erase(command.find_last_not_of(" \n\t\r")+1);

		if (command.empty() == true)
			continue;

		cout << "Dobil sem ukaz: \"" << command << "\"" << endl;
		
		message.str("");
		
		if (command == "levo")
		{
			message << "Zavijam levo!" << endl; 
		}
		else if (command == "desno")
		{
			message << "Zavijam desno!" << endl; 
		}
		else if (command == "izklop")
		{
			message << "Izklapljam se! Adijo!" << endl; 
		}
		else
		{
			message << "Ne razumem! Prosim, ponovi ukaz!" << endl; 
		}

		cout << message.str();

		if (command == "izklop")
			return 0;
	}

    	return 0;
}
