#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/fcntl.h>
#include <sys/socket.h>
#include <errno.h>

#define 	STRING_SIZE	512
#define 	BUF_SIZE	1024
#define 	TCPIP_PORT	4966

int main(argc,argv)
int  argc;
char *argv[];
{
  int	n,n_read,n_written,addr_len;
  int	caller,lcaller,fd_out,port_num,single_session_flag;

  char unsigned *ap,*buf;

  static char	buffer[BUF_SIZE],host_name[STRING_SIZE];

  struct 	sockaddr_in	sin_addr,rin_addr;


  port_num=TCPIP_PORT;
  single_session_flag = 0;

  /* 
  ** Check arguments
  */

  if(argc>1)
  {
    for(n=1;n<argc;n++)
    {
      if(!strncmp(argv[n],"-port",5) && n < argc-1)
        port_num=atoi(argv[n+1]);

      if(!strncmp(argv[n],"-oneses",7))
        single_session_flag = 1;

      if(!strncmp(argv[n],"-help",5))
      {
        fprintf(stderr,"\n                       -= TCP/IP Stream Data Receiver =-\n");
        fprintf(stderr,"                 Simon Dobri�ek, Copyright (c) November, 1995\n");
        fprintf(stderr,"                 ------------------------------------------\n\n");
        fprintf(stderr,"                    Current parameter: TCP/IP port=%d\n",port_num);
        fprintf(stderr,"                      Optional Switch: -port <port number>\n");
        fprintf(stderr,"                                       -oneses\n\n");
        exit(0);
      }
    }
  }


  memset(&sin_addr,0,sizeof(sin_addr));
  sin_addr.sin_family=AF_INET;
  sin_addr.sin_port=htons(port_num);
  sin_addr.sin_addr.s_addr=INADDR_ANY;

  if((lcaller=socket(AF_INET,SOCK_STREAM,0))<0)
  {
    fprintf(stderr,"\n%s: Socket creation failed ... %s  :(\n\n",argv[0],strerror(errno));
    exit(1);
  }

  if((bind(lcaller,(struct sockaddr *)&sin_addr,sizeof(sin_addr)))<0)
  {
    fprintf(stderr,"\n%s: Bind failed ... %s  :(\n\n",argv[0],strerror(errno));
    exit(1);
  }

  if((listen(lcaller,5))<0)
  {
    fprintf(stderr,"\n%s: Listen failed ... %s  :(\n\n",argv[0],strerror(errno));
    exit(1);
  }

  sleep(1);
  fprintf(stderr,"%s: is waiting for connections on port %d ... \n",argv[0],port_num);

  fd_out=fileno(stdout);

  for(;;)
  {
    addr_len = sizeof(sin_addr);
    if((caller = accept(lcaller,(struct sockaddr *)&sin_addr,&addr_len))<0)
    {
      fprintf(stderr,"\n%s: Accept failed ... %s  :(\n\n",argv[0],strerror(errno));
      exit(1);
    }

    addr_len=sizeof(rin_addr);
    if(getpeername(caller,(struct sockaddr *)&rin_addr,&addr_len)<0)
    {
      fprintf(stderr,"\n%s: Getpeername failed ... %s  :(\n\n",argv[0],strerror(errno));
      exit(1);
    }

  
    ap=(char unsigned *)(&rin_addr.sin_addr.s_addr);
    sprintf(host_name,"%u.%u.%u.%u",ap[0],ap[1],ap[2],ap[3]);

    fprintf(stderr,"%s: The connection is established with %s ... :)\n",argv[0],host_name);

    for(;;)
    {
      if((n_read=read(caller,buffer,BUF_SIZE))<=0)
      {
        if(n_read < 0)
	  fprintf(stderr,"\n%s: Read failed ... %s  :(\n\n",argv[0],strerror(errno));
        fprintf(stderr,"%s: is waiting for new connections on port %d ... \n",argv[0],port_num);
        
	if(single_session_flag)
	  exit(0);
	else
	  break;
      }

      for(buf=(char unsigned *)buffer; n_read ; n_read-=n_written, buf+=n_written)
        if((n_written=write(fd_out,buf,n_read))<=0)
        {
          fprintf(stderr,"\n%s: Write failed ... %s  :(\n\n",argv[0],strerror(errno));
          exit(1);;
        }
    }
  }

  return 0;
}
