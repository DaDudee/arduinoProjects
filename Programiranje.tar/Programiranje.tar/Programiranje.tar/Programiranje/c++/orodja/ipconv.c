#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/fcntl.h>
#include <errno.h>
#include <iconv.h>


#define 	BUF_SIZE  1024	

int main(argc,argv)
int  argc;
char *argv[];
{
  size_t n_read,n_written,n_converted;
  int	 fd_in,fd_out;
  char*  buf;

  static char	ibuffer[BUF_SIZE];
  static char   obuffer[BUF_SIZE];

  char* inp = (char *)ibuffer;
  char* outp = (char *)obuffer;

  iconv_t cd = iconv_open("CP1250", "UTF-8");

  fd_in = fileno(stdin);
  fd_out = fileno(stdout);

  for(;;)
  {
    memset(ibuffer,0,BUF_SIZE);
    memset(obuffer,0,BUF_SIZE);

    if((n_read=read(fd_in,ibuffer,BUF_SIZE))<=0)
    {
      if(n_read < 0)
        fprintf(stderr,"\n%s: Read failed ... %s  :(\n\n",argv[0],strerror(errno));
      exit(1);
    }

    //fprintf(stderr,"n_read=%lu\n",n_read);             

    n_converted = n_read;

    inp = (char *)ibuffer;
    outp = (char *)obuffer;

    if(iconv(cd, &inp, &n_read, &outp, &n_converted)<0)
    {
      fprintf(stderr,"\n%s: Character conversion failed ... %s  :(\n\n",argv[0],strerror(errno));
      exit(1);  
    }

    for(n_converted=0;obuffer[n_converted]!=0;n_converted++);
    
    //fprintf(stderr,"n_converted=%lu\n",n_converted);

    n_read = n_converted;

    for(buf=obuffer; n_read ; n_read-=n_written, buf+=n_written)
      if((n_written=write(fd_out,buf,n_read))<=0)
      {
        fprintf(stderr,"\n%s: Write failed ... %s  :(\n\n",argv[0],strerror(errno));
        exit(1);
      }
  }

  iconv_close(cd);

  return 0;
}
